
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'alexzmcginnis',
  applicationName: 'serverless',
  appUid: 'Zgn9nVNLTCwHWqQP3v',
  orgUid: 'c63bd5fa-a9da-4e23-8f4d-8164e006aa98',
  deploymentUid: 'd7e3bace-31f2-464b-93c3-9e37a3ffadf5',
  serviceName: 'serverless',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.5.1',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'serverless-dev-helloWorld', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.hello, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}